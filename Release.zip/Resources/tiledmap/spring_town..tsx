<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="spring_town." tilewidth="16" tileheight="16" tilecount="1984" columns="32">
 <image source="spring_town..png" width="512" height="992"/>
 <tile id="1041">
  <animation>
   <frame tileid="1041" duration="100"/>
   <frame tileid="1039" duration="100"/>
   <frame tileid="1038" duration="100"/>
   <frame tileid="1037" duration="100"/>
   <frame tileid="1069" duration="100"/>
  </animation>
 </tile>
 <tile id="1042">
  <animation>
   <frame tileid="1042" duration="100"/>
   <frame tileid="1201" duration="100"/>
   <frame tileid="1202" duration="100"/>
   <frame tileid="1203" duration="100"/>
   <frame tileid="1204" duration="100"/>
   <frame tileid="1205" duration="100"/>
   <frame tileid="1206" duration="100"/>
  </animation>
 </tile>
 <tile id="1043">
  <animation>
   <frame tileid="1043" duration="100"/>
   <frame tileid="1070" duration="100"/>
   <frame tileid="1102" duration="100"/>
   <frame tileid="1101" duration="100"/>
  </animation>
 </tile>
 <tile id="1074">
  <animation>
   <frame tileid="1074" duration="100"/>
   <frame tileid="1233" duration="100"/>
   <frame tileid="1234" duration="100"/>
   <frame tileid="1235" duration="100"/>
   <frame tileid="1236" duration="100"/>
   <frame tileid="1237" duration="100"/>
   <frame tileid="1238" duration="100"/>
  </animation>
 </tile>
 <tile id="1106">
  <animation>
   <frame tileid="1265" duration="100"/>
   <frame tileid="1266" duration="100"/>
   <frame tileid="1267" duration="100"/>
   <frame tileid="1268" duration="100"/>
   <frame tileid="1269" duration="100"/>
   <frame tileid="1270" duration="100"/>
  </animation>
 </tile>
</tileset>
