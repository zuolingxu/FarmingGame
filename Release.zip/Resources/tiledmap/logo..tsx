<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="logo." tilewidth="16" tileheight="16" tilecount="325" columns="25">
 <image source="logo..png" width="400" height="220"/>
</tileset>
