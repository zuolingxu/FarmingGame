<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="spring_outdoorsTileSheet." tilewidth="16" tileheight="16" tilecount="1975" columns="25">
 <image source="spring_outdoorsTileSheet..png" width="400" height="1264"/>
 <tile id="420">
  <animation>
   <frame tileid="420" duration="200"/>
   <frame tileid="421" duration="200"/>
   <frame tileid="422" duration="200"/>
   <frame tileid="423" duration="200"/>
  </animation>
 </tile>
 <tile id="1115">
  <animation>
   <frame tileid="1115" duration="200"/>
   <frame tileid="1117" duration="200"/>
  </animation>
 </tile>
 <tile id="1116">
  <animation>
   <frame tileid="1116" duration="200"/>
   <frame tileid="1118" duration="200"/>
  </animation>
 </tile>
</tileset>
