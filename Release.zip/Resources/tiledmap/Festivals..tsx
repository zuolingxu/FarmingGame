<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Festivals." tilewidth="16" tileheight="16" tilecount="1024" columns="32">
 <image source="Festivals..png" width="512" height="512"/>
 <tile id="15">
  <animation>
   <frame tileid="15" duration="100"/>
   <frame tileid="16" duration="100"/>
   <frame tileid="17" duration="100"/>
   <frame tileid="18" duration="100"/>
   <frame tileid="19" duration="100"/>
  </animation>
 </tile>
 <tile id="428">
  <animation>
   <frame tileid="428" duration="100"/>
   <frame tileid="430" duration="100"/>
   <frame tileid="432" duration="100"/>
  </animation>
 </tile>
 <tile id="429">
  <animation>
   <frame tileid="429" duration="100"/>
   <frame tileid="431" duration="100"/>
   <frame tileid="433" duration="100"/>
  </animation>
 </tile>
 <tile id="460">
  <animation>
   <frame tileid="460" duration="100"/>
   <frame tileid="462" duration="100"/>
   <frame tileid="464" duration="100"/>
  </animation>
 </tile>
 <tile id="461">
  <animation>
   <frame tileid="461" duration="100"/>
   <frame tileid="463" duration="100"/>
   <frame tileid="465" duration="100"/>
  </animation>
 </tile>
 <tile id="492">
  <animation>
   <frame tileid="492" duration="100"/>
   <frame tileid="494" duration="100"/>
   <frame tileid="495" duration="100"/>
   <frame tileid="496" duration="100"/>
   <frame tileid="497" duration="100"/>
   <frame tileid="496" duration="100"/>
   <frame tileid="495" duration="100"/>
   <frame tileid="494" duration="100"/>
   <frame tileid="492" duration="100"/>
  </animation>
 </tile>
</tileset>
